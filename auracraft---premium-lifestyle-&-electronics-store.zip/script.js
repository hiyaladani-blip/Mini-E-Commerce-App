/**
 * AuraCraft - Interactive E-Commerce Store with Shopping Cart
 * Pure Vanilla JavaScript (ES6+) Implementation
 * 
 * Features:
 * - Dynamic product catalog rendering from JavaScript object array
 * - Full interactive shopping cart (add, increase/decrease qty, remove)
 * - Accurate pricing calculations via reduce() with conditional delivery tiers
 * - LocalStorage persistence with defensive schema validation
 * - Checkout preview modal with Order Summary & demo disclaimer
 * - Live search, category filtering, sorting, and toast notifications
 */

// =============================================================================
// 1. PRODUCT CATALOG DATA (Numeric prices, unique IDs)
// =============================================================================
const PRODUCTS = [
  {
    id: 1,
    name: "Sony WH-1000XM5 Wireless Headphones",
    category: "Audio",
    price: 26990,
    rating: 4.9,
    reviews: 1420,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700&auto=format&fit=crop&q=80",
    description: "Industry-leading noise canceling with two processors and 8 microphones for exceptional sound quality."
  },
  {
    id: 2,
    name: "Apple Watch Series 9 GPS 45mm",
    category: "Wearables",
    price: 41900,
    rating: 4.8,
    reviews: 980,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&auto=format&fit=crop&q=80",
    description: "Powerful S9 SiP chip, double tap gesture control, and comprehensive health & fitness tracking."
  },
  {
    id: 3,
    name: "Logitech MX Master 3S Wireless Mouse",
    category: "Accessories",
    price: 8995,
    rating: 4.8,
    reviews: 2150,
    image: "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=700&auto=format&fit=crop&q=80",
    description: "Ergonomic quiet-click mouse with 8K DPI glass sensor and MagSpeed electromagnetic scrolling."
  },
  {
    id: 4,
    name: "Keychron K2 Pro Mechanical Keyboard",
    category: "Accessories",
    price: 7499,
    rating: 4.7,
    reviews: 640,
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=700&auto=format&fit=crop&q=80",
    description: "Wireless custom mechanical keyboard with QMK/VIA support, hot-swappable switches, and RGB backlighting."
  },
  {
    id: 5,
    name: "JBL Flip 6 Waterproof Bluetooth Speaker",
    category: "Audio",
    price: 9999,
    rating: 4.6,
    reviews: 1820,
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=700&auto=format&fit=crop&q=80",
    description: "Bold 2-way speaker system delivering powerful, crystal-clear sound with IP67 waterproof durability."
  },
  {
    id: 6,
    name: "Fujifilm Instax Mini 12 Instant Camera",
    category: "Photography",
    price: 6499,
    rating: 4.5,
    reviews: 890,
    image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=700&auto=format&fit=crop&q=80",
    description: "Compact instant camera with auto exposure, built-in selfie mirror, and close-up lens mode."
  },
  {
    id: 7,
    name: "BenQ ScreenBar Halo LED Desk Lamp",
    category: "Home & Office",
    price: 12990,
    rating: 4.7,
    reviews: 430,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700&auto=format&fit=crop&q=80",
    description: "Intelligent monitor-mounted eye-care light with rear ambient backlight and wireless controller."
  },
  {
    id: 8,
    name: "Anker 737 Power Bank (24,000mAh 140W)",
    category: "Accessories",
    price: 11499,
    rating: 4.9,
    reviews: 760,
    image: "https://images.unsplash.com/photo-1609592426505-1886ee46df3c?w=700&auto=format&fit=crop&q=80",
    description: "Ultra-powerful two-way fast charging battery with smart digital display and Power Delivery 3.1."
  },
  {
    id: 9,
    name: "Marshall Emberton II Portable Speaker",
    category: "Audio",
    price: 14999,
    rating: 4.8,
    reviews: 520,
    image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=700&auto=format&fit=crop&q=80",
    description: "Rich, multi-directional 360° True Stereophonic sound with 30+ hours of portable playtime."
  },
  {
    id: 10,
    name: "Bose QuietComfort Ultra Earbuds",
    category: "Audio",
    price: 21990,
    rating: 4.7,
    reviews: 610,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=700&auto=format&fit=crop&q=80",
    description: "Breakthrough spatialized audio with CustomTune sound calibration and world-class noise cancellation."
  },
  {
    id: 11,
    name: "Ceramic Desk Coffee Mug & Warmer Set",
    category: "Home & Office",
    price: 499,
    rating: 4.4,
    reviews: 310,
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=700&auto=format&fit=crop&q=80",
    description: "Thermostatic heating coaster keeps coffee or tea at a pleasant 55°C all day long."
  },
  {
    id: 12,
    name: "Braided USB-C Fast Charging Cable (2-Pack)",
    category: "Accessories",
    price: 349,
    rating: 4.3,
    reviews: 1240,
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=700&auto=format&fit=crop&q=80",
    description: "Heavy-duty nylon braided 60W USB-C cables with reinforced aluminum alloy connector housings."
  }
];

// Delivery fee configuration constants
const DELIVERY_THRESHOLD = 500;
const STANDARD_DELIVERY_FEE = 40;
const STORAGE_KEY = 'auracraft_cart_v1';

// =============================================================================
// 2. STATE MANAGEMENT
// =============================================================================
/**
 * Cart State: Array of { id: number, quantity: number }
 */
let cart = [];
let activeCategory = 'All';
let searchQuery = '';
let activeSort = 'featured';

// =============================================================================
// 3. CURRENCY FORMATTING HELPER
// =============================================================================
/**
 * Formats a numeric price into Indian Rupee currency format (e.g. ₹26,990.00 or ₹26,990)
 * Uses native Intl / toLocaleString('en-IN', { style: 'currency', currency: 'INR' })
 */
function formatCurrency(amount) {
  if (typeof amount !== 'number' || isNaN(amount)) {
    return '₹0.00';
  }
  return amount.toLocaleString('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
    minimumFractionDigits: 0
  });
}

// =============================================================================
// 4. LOCALSTORAGE PERSISTENCE (Safe load & save)
// =============================================================================
/**
 * Loads cart from LocalStorage with defensive validation against corrupt data
 */
function loadCart() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      cart = [];
      return;
    }
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed)) {
      cart = [];
      return;
    }
    // Validate each item: must have valid numeric ID found in PRODUCTS and integer quantity > 0
    cart = parsed.filter(item => {
      if (!item || typeof item !== 'object') return false;
      const numericId = Number(item.id);
      const qty = Number(item.quantity);
      const exists = PRODUCTS.some(p => p.id === numericId);
      return exists && Number.isInteger(qty) && qty > 0;
    }).map(item => ({
      id: Number(item.id),
      quantity: Number(item.quantity)
    }));
  } catch (error) {
    console.warn('Could not parse cart from LocalStorage. Initializing empty cart.', error);
    cart = [];
  }
}

/**
 * Persists current cart to LocalStorage
 */
function saveCart() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
  } catch (error) {
    console.error('Failed to save cart to LocalStorage:', error);
  }
}

// =============================================================================
// 5. TOTAL PRICE CALCULATION (Using Array.prototype.reduce)
// =============================================================================
/**
 * Computes subtotal, delivery fee, and grand total using reduce()
 * Rules:
 * - Subtotal = sum of (price * quantity)
 * - Empty cart => deliveryFee = 0
 * - Subtotal >= 500 => deliveryFee = 0 (Free Delivery)
 * - Subtotal < 500 => deliveryFee = 40
 * - Grand Total = Subtotal + deliveryFee
 */
function calculateCartTotals() {
  // Compute subtotal via reduce
  const subtotal = cart.reduce((total, cartItem) => {
    const product = PRODUCTS.find(p => p.id === cartItem.id);
    if (!product) return total;
    return total + (product.price * cartItem.quantity);
  }, 0);

  // Compute delivery fee
  let deliveryFee = 0;
  if (cart.length > 0) {
    deliveryFee = subtotal >= DELIVERY_THRESHOLD ? 0 : STANDARD_DELIVERY_FEE;
  }

  // Grand total
  const grandTotal = subtotal + deliveryFee;

  // Total quantity of items in cart
  const totalItemCount = cart.reduce((count, item) => count + item.quantity, 0);

  return {
    subtotal,
    deliveryFee,
    grandTotal,
    totalItemCount
  };
}

// =============================================================================
// 6. CORE SHOPPING CART OPERATIONS
// =============================================================================

/**
 * Adds product to cart. If already present, increments quantity by 1.
 * Updates LocalStorage and immediately re-renders UI.
 */
function addToCart(id) {
  const numericId = Number(id);
  const product = PRODUCTS.find(p => p.id === numericId);

  if (!product) {
    console.warn(`Product with ID "${id}" was not found.`);
    return;
  }

  const existingItem = cart.find(item => item.id === numericId);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: numericId,
      quantity: 1
    });
  }

  saveCart();
  updateCartBadge();
  renderCart();
  showToast(`Added to cart: ${product.name}`);

  // Visual feedback on the clicked button if present in DOM
  const addBtn = document.querySelector(`.btn-add-to-cart[data-id="${numericId}"]`);
  if (addBtn) {
    const originalText = addBtn.innerHTML;
    addBtn.classList.add('added');
    addBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
      <span>Added!</span>
    `;
    setTimeout(() => {
      addBtn.classList.remove('added');
      addBtn.innerHTML = originalText;
    }, 1400);
  }
}

/**
 * Changes quantity of a cart item by delta (+1 or -1).
 * If quantity drops to 0 or below, removes product from cart.
 */
function changeQuantity(id, delta) {
  const numericId = Number(id);
  const itemIndex = cart.findIndex(item => item.id === numericId);

  if (itemIndex === -1) {
    console.warn(`Item with ID "${id}" is not in the cart.`);
    return;
  }

  const newQty = cart[itemIndex].quantity + delta;

  if (newQty <= 0) {
    // Automatically remove product if its quantity becomes zero
    cart.splice(itemIndex, 1);
  } else {
    cart[itemIndex].quantity = newQty;
  }

  saveCart();
  updateCartBadge();
  renderCart();
}

/**
 * Removes a product completely from the cart
 */
function removeItem(id) {
  const numericId = Number(id);
  const product = PRODUCTS.find(p => p.id === numericId);
  const initialLen = cart.length;

  cart = cart.filter(item => item.id !== numericId);

  if (cart.length !== initialLen) {
    saveCart();
    updateCartBadge();
    renderCart();
    if (product) {
      showToast(`Removed from cart: ${product.name}`);
    }
  }
}

/**
 * Clears the entire cart with user confirmation
 */
function clearCart() {
  if (cart.length === 0) return;
  if (confirm('Are you sure you want to remove all items from your cart?')) {
    cart = [];
    saveCart();
    updateCartBadge();
    renderCart();
    showToast('Your shopping cart has been cleared.');
  }
}

// =============================================================================
// 7. DYNAMIC UI RENDERING
// =============================================================================

/**
 * Updates the navigation badge counter and triggers pop animation
 */
function updateCartBadge() {
  const badgeEl = document.getElementById('headerCartCount');
  const drawerCountEl = document.getElementById('drawerItemCount');
  const totals = calculateCartTotals();

  if (badgeEl) {
    badgeEl.textContent = totals.totalItemCount;
    badgeEl.classList.remove('badge-pop');
    // Force reflow to re-trigger CSS animation
    void badgeEl.offsetWidth;
    badgeEl.classList.add('badge-pop');
  }

  if (drawerCountEl) {
    drawerCountEl.textContent = `${totals.totalItemCount} ${totals.totalItemCount === 1 ? 'item' : 'items'}`;
  }
}

/**
 * Dynamically renders product catalog cards based on search and active category
 */
function renderProducts() {
  const container = document.getElementById('productGrid');
  const countBar = document.getElementById('resultsCount');
  if (!container) return;

  // Filter products by category and search query
  let filtered = PRODUCTS.filter(product => {
    const matchesCategory = (activeCategory === 'All') || (product.category === activeCategory);
    const matchesSearch = !searchQuery ||
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Apply sorting
  filtered = sortProducts(filtered, activeSort);

  // Update results count label
  if (countBar) {
    const categoryLabel = activeCategory === 'All' ? 'all categories' : `"${activeCategory}"`;
    const searchLabel = searchQuery ? ` matching "${searchQuery}"` : '';
    countBar.textContent = `Showing ${filtered.length} of ${PRODUCTS.length} products in ${categoryLabel}${searchLabel}`;
  }

  // Handle empty search / filter results
  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-catalog">
        <div class="empty-catalog-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
        </div>
        <h3>No matching products found</h3>
        <p>We couldn't find any items matching "${searchQuery}". Try searching with different keywords or reset your category filters.</p>
        <button id="resetSearchBtn" class="btn-primary" style="margin: 0 auto;">
          <span>Clear All Filters</span>
        </button>
      </div>
    `;

    const resetBtn = document.getElementById('resetSearchBtn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        resetAllFilters();
      });
    }
    return;
  }

  // Generate cards dynamically using DOM manipulation
  container.innerHTML = '';
  filtered.forEach(product => {
    const card = document.createElement('article');
    card.className = 'product-card';
    card.setAttribute('data-id', product.id);

    // Delivery tier indicator
    const isFreeEligible = product.price >= DELIVERY_THRESHOLD;
    const badgeMarkup = isFreeEligible
      ? `<span class="product-badge-tier badge-free-del">Free Delivery</span>`
      : `<span class="product-badge-tier badge-fee-del">+₹40 Delivery</span>`;

    card.innerHTML = `
      <div class="product-image-wrapper">
        <img 
          src="${product.image}" 
          alt="${product.name}" 
          class="product-image"
          loading="lazy"
          onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1526738549149-8e07eca6c147?w=700&auto=format&fit=crop&q=80';"
        />
        <span class="product-category-tag">${product.category}</span>
        ${badgeMarkup}
      </div>
      <div class="product-card-body">
        <div class="product-rating">
          <div class="stars-icon">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
          </div>
          <span class="rating-score">${product.rating}</span>
          <span class="rating-count">(${product.reviews.toLocaleString('en-IN')})</span>
        </div>
        <h3 class="product-name" title="${product.name}">${product.name}</h3>
        <p class="product-desc">${product.description}</p>
        <div class="product-card-footer">
          <div class="product-price-box">
            <span class="price-label">Price</span>
            <span class="product-price-value">${formatCurrency(product.price)}</span>
          </div>
          <button 
            type="button"
            class="btn-add-to-cart" 
            data-id="${product.id}"
            aria-label="Add ${product.name} to shopping cart"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <path d="M16 10a4 4 0 0 1-8 0"></path>
            </svg>
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });
}

/**
 * Sorts products array by selected criteria
 */
function sortProducts(list, criteria) {
  const copy = [...list];
  switch (criteria) {
    case 'price-low':
      return copy.sort((a, b) => a.price - b.price);
    case 'price-high':
      return copy.sort((a, b) => b.price - a.price);
    case 'rating':
      return copy.sort((a, b) => b.rating - a.rating);
    case 'name':
      return copy.sort((a, b) => a.name.localeCompare(b.name));
    case 'featured':
    default:
      return copy; // original curated order
  }
}

/**
 * Dynamically renders the cart drawer contents, quantity controls,
 * empty state, delivery progress meter, and totals
 */
function renderCart() {
  const itemsContainer = document.getElementById('cartItemsContainer');
  const footerEl = document.getElementById('cartDrawerFooter');
  const subtotalEl = document.getElementById('cartSubtotal');
  const deliveryEl = document.getElementById('cartDeliveryFee');
  const totalEl = document.getElementById('cartGrandTotal');
  const deliveryMeterEl = document.getElementById('deliveryMeter');
  const checkoutBtn = document.getElementById('openCheckoutBtn');

  if (!itemsContainer) return;

  const totals = calculateCartTotals();

  // If cart is empty, render friendly empty state
  if (cart.length === 0) {
    itemsContainer.innerHTML = `
      <div class="empty-cart-view">
        <div class="empty-cart-illustration">
          <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75">
            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <path d="M16 10a4 4 0 0 1-8 0"></path>
          </svg>
        </div>
        <h4>Your cart is empty</h4>
        <p>Explore our premium catalog and find your next favorite tech gear or lifestyle essential.</p>
        <button id="startShoppingBtn" class="btn-primary" type="button">
          <span>Start Shopping</span>
        </button>
      </div>
    `;

    const startBtn = document.getElementById('startShoppingBtn');
    if (startBtn) {
      startBtn.addEventListener('click', () => {
        closeCartDrawer();
        const catalogSec = document.getElementById('catalog');
        if (catalogSec) {
          catalogSec.scrollIntoView({ behavior: 'smooth' });
        }
      });
    }

    if (deliveryMeterEl) {
      deliveryMeterEl.style.display = 'none';
    }

    if (footerEl) {
      footerEl.style.display = 'none';
    }

    if (checkoutBtn) {
      checkoutBtn.disabled = true;
    }

    return;
  }

  // Cart has items: Show meter & footer
  if (footerEl) {
    footerEl.style.display = 'block';
  }

  if (checkoutBtn) {
    checkoutBtn.disabled = false;
  }

  // Render Free Delivery Progress Meter
  if (deliveryMeterEl) {
    deliveryMeterEl.style.display = 'block';
    const percent = Math.min(100, Math.round((totals.subtotal / DELIVERY_THRESHOLD) * 100));
    const remaining = DELIVERY_THRESHOLD - totals.subtotal;

    if (totals.subtotal >= DELIVERY_THRESHOLD) {
      deliveryMeterEl.innerHTML = `
        <div class="delivery-meter-text" style="color: var(--accent-emerald);">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          <span>🎉 You've unlocked <strong>FREE Delivery!</strong></span>
        </div>
        <div class="delivery-progress-track">
          <div class="delivery-progress-bar" style="width: 100%; background: var(--accent-emerald);"></div>
        </div>
      `;
    } else {
      deliveryMeterEl.innerHTML = `
        <div class="delivery-meter-text">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="1" y="3" width="15" height="13"></rect>
            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
            <circle cx="5.5" cy="18.5" r="2.5"></circle>
            <circle cx="18.5" cy="18.5" r="2.5"></circle>
          </svg>
          <span>Add <strong>${formatCurrency(remaining)}</strong> more to get <strong>FREE Delivery</strong></span>
        </div>
        <div class="delivery-progress-track">
          <div class="delivery-progress-bar" style="width: ${percent}%;"></div>
        </div>
      `;
    }
  }

  // Render Cart Item Cards
  itemsContainer.innerHTML = '';
  cart.forEach(item => {
    const product = PRODUCTS.find(p => p.id === item.id);
    if (!product) return;

    const lineTotal = product.price * item.quantity;
    const itemCard = document.createElement('div');
    itemCard.className = 'cart-item';
    itemCard.setAttribute('data-id', item.id);

    itemCard.innerHTML = `
      <img 
        src="${product.image}" 
        alt="${product.name}" 
        class="cart-item-thumb"
        onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1526738549149-8e07eca6c147?w=700&auto=format&fit=crop&q=80';"
      />
      <div class="cart-item-info">
        <h4 class="cart-item-name" title="${product.name}">${product.name}</h4>
        <span class="cart-item-unit-price">${formatCurrency(product.price)} each</span>
        <div class="cart-qty-controls">
          <button 
            type="button" 
            class="qty-btn btn-qty-minus" 
            data-id="${item.id}"
            aria-label="Decrease quantity of ${product.name}"
          >−</button>
          <span class="qty-value">${item.quantity}</span>
          <button 
            type="button" 
            class="qty-btn btn-qty-plus" 
            data-id="${item.id}"
            aria-label="Increase quantity of ${product.name}"
          >+</button>
        </div>
      </div>
      <div class="cart-item-actions">
        <span class="cart-item-line-total">${formatCurrency(lineTotal)}</span>
        <button 
          type="button" 
          class="btn-remove-item" 
          data-id="${item.id}"
          title="Remove item from cart"
          aria-label="Remove ${product.name} from cart"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    `;

    itemsContainer.appendChild(itemCard);
  });

  // Update Summary Rows in Footer
  if (subtotalEl) {
    subtotalEl.textContent = formatCurrency(totals.subtotal);
  }

  if (deliveryEl) {
    if (totals.deliveryFee === 0) {
      deliveryEl.innerHTML = `<span class="badge-delivery-free">FREE</span>`;
    } else {
      deliveryEl.innerHTML = `<span class="badge-delivery-fee">${formatCurrency(totals.deliveryFee)}</span>`;
    }
  }

  if (totalEl) {
    totalEl.textContent = formatCurrency(totals.grandTotal);
  }
}

// =============================================================================
// 8. CHECKOUT PREVIEW MODAL
// =============================================================================

/**
 * Opens and renders the Checkout Preview Modal with Order Summary and Disclaimer
 */
function openCheckoutModal() {
  if (cart.length === 0) {
    showToast('Your cart is empty. Add items before checking out.');
    return;
  }

  const backdrop = document.getElementById('checkoutModalBackdrop');
  const itemsContainer = document.getElementById('modalOrderItems');
  const subtotalEl = document.getElementById('modalSubtotal');
  const deliveryEl = document.getElementById('modalDeliveryFee');
  const grandTotalEl = document.getElementById('modalGrandTotal');
  const initialView = document.getElementById('checkoutInitialView');
  const successView = document.getElementById('checkoutSuccessView');

  if (!backdrop) return;

  // Reset to initial review view (in case previous demo order was placed)
  if (initialView) initialView.style.display = 'block';
  if (successView) successView.style.display = 'none';

  const totals = calculateCartTotals();

  // Populate preview item rows
  if (itemsContainer) {
    itemsContainer.innerHTML = '';
    cart.forEach(item => {
      const product = PRODUCTS.find(p => p.id === item.id);
      if (!product) return;
      const lineTotal = product.price * item.quantity;

      const row = document.createElement('div');
      row.className = 'preview-item-row';
      row.innerHTML = `
        <img src="${product.image}" alt="${product.name}" class="preview-item-img" />
        <div class="preview-item-title" title="${product.name}">${product.name}</div>
        <div class="preview-item-qty">Qty: ${item.quantity} × ${formatCurrency(product.price)}</div>
        <div class="preview-item-total">${formatCurrency(lineTotal)}</div>
      `;
      itemsContainer.appendChild(row);
    });
  }

  // Populate totals
  if (subtotalEl) subtotalEl.textContent = formatCurrency(totals.subtotal);

  if (deliveryEl) {
    if (totals.deliveryFee === 0) {
      deliveryEl.innerHTML = `<span class="badge-delivery-free">FREE (Subtotal ≥ ₹500)</span>`;
    } else {
      deliveryEl.innerHTML = `<span class="badge-delivery-fee">${formatCurrency(totals.deliveryFee)} (Standard delivery under ₹500)</span>`;
    }
  }

  if (grandTotalEl) grandTotalEl.textContent = formatCurrency(totals.grandTotal);

  // Close drawer if open, show modal
  closeCartDrawer();
  backdrop.classList.add('open');
  document.body.style.overflow = 'hidden';
}

/**
 * Closes the checkout modal
 */
function closeCheckoutModal() {
  const backdrop = document.getElementById('checkoutModalBackdrop');
  if (backdrop) {
    backdrop.classList.remove('open');
    document.body.style.overflow = '';
  }
}

/**
 * Confirms the demo order: clears cart, saves state, displays success screen
 */
function handleConfirmDemoOrder() {
  if (cart.length === 0) return;

  const totals = calculateCartTotals();
  const orderId = `AC-${Math.floor(100000 + Math.random() * 900000)}`;

  // Clear cart & update LocalStorage
  cart = [];
  saveCart();
  updateCartBadge();
  renderCart();

  // Switch to success view inside modal
  const initialView = document.getElementById('checkoutInitialView');
  const successView = document.getElementById('checkoutSuccessView');
  const orderNumberEl = document.getElementById('successOrderNumber');
  const successTotalEl = document.getElementById('successOrderTotal');

  if (orderNumberEl) orderNumberEl.textContent = orderId;
  if (successTotalEl) successTotalEl.textContent = formatCurrency(totals.grandTotal);

  if (initialView) initialView.style.display = 'none';
  if (successView) successView.style.display = 'flex';
}

// =============================================================================
// 9. CART DRAWER TOGGLE & OVERLAYS
// =============================================================================
function openCartDrawer() {
  const drawer = document.getElementById('cartDrawer');
  const overlay = document.getElementById('cartOverlay');
  if (drawer && overlay) {
    drawer.classList.add('open');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function closeCartDrawer() {
  const drawer = document.getElementById('cartDrawer');
  const overlay = document.getElementById('cartOverlay');
  if (drawer && overlay) {
    drawer.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}

// =============================================================================
// 10. TOAST NOTIFICATION SYSTEM
// =============================================================================
let toastTimeout = null;

function showToast(message) {
  let toastContainer = document.getElementById('toastContainer');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toastContainer';
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);
  }

  // Remove existing toast if any
  toastContainer.innerHTML = '';
  if (toastTimeout) {
    clearTimeout(toastTimeout);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <div class="toast-icon">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
    </div>
    <div class="toast-content">
      <div class="toast-title">Cart Updated</div>
      <div class="toast-desc">${message}</div>
    </div>
    <button type="button" class="toast-action-btn" id="toastViewCartBtn">View Cart</button>
  `;

  toastContainer.appendChild(toast);

  // Trigger animation
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  const viewCartBtn = toast.querySelector('#toastViewCartBtn');
  if (viewCartBtn) {
    viewCartBtn.addEventListener('click', () => {
      openCartDrawer();
      toast.classList.remove('show');
    });
  }

  toastTimeout = setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 300);
  }, 3500);
}

// =============================================================================
// 11. FILTER & SEARCH HANDLERS
// =============================================================================
function handleCategorySelect(category) {
  activeCategory = category;

  // Update pill buttons state
  document.querySelectorAll('.filter-pill-btn').forEach(btn => {
    if (btn.getAttribute('data-category') === category) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  renderProducts();
}

function handleSearchInput(e) {
  searchQuery = e.target.value.trim();

  // Sync both search inputs (navbar and catalog)
  const navInput = document.getElementById('navSearchInput');
  const catalogInput = document.getElementById('catalogSearchInput');
  const navClear = document.getElementById('navSearchClear');
  const catalogClear = document.getElementById('catalogSearchClear');

  if (navInput && navInput !== e.target) navInput.value = searchQuery;
  if (catalogInput && catalogInput !== e.target) catalogInput.value = searchQuery;

  if (navClear) navClear.style.display = searchQuery ? 'block' : 'none';
  if (catalogClear) catalogClear.style.display = searchQuery ? 'block' : 'none';

  renderProducts();
}

function resetAllFilters() {
  activeCategory = 'All';
  searchQuery = '';
  activeSort = 'featured';

  const navInput = document.getElementById('navSearchInput');
  const catalogInput = document.getElementById('catalogSearchInput');
  const navClear = document.getElementById('navSearchClear');
  const catalogClear = document.getElementById('catalogSearchClear');
  const sortSelect = document.getElementById('sortSelect');

  if (navInput) navInput.value = '';
  if (catalogInput) catalogInput.value = '';
  if (navClear) navClear.style.display = 'none';
  if (catalogClear) catalogClear.style.display = 'none';
  if (sortSelect) sortSelect.value = 'featured';

  document.querySelectorAll('.filter-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-category') === 'All');
  });

  renderProducts();
}

// =============================================================================
// 12. GLOBAL EVENT DELEGATION & INITIALIZATION
// =============================================================================

function setupEventListeners() {
  // Cart Drawer open/close buttons
  const cartTrigger = document.getElementById('headerCartBtn');
  const closeDrawerBtn = document.getElementById('closeCartDrawerBtn');
  const cartOverlay = document.getElementById('cartOverlay');
  const clearCartBtn = document.getElementById('clearCartLink');

  if (cartTrigger) cartTrigger.addEventListener('click', openCartDrawer);
  if (closeDrawerBtn) closeDrawerBtn.addEventListener('click', closeCartDrawer);
  if (cartOverlay) cartOverlay.addEventListener('click', closeCartDrawer);
  if (clearCartBtn) clearCartBtn.addEventListener('click', clearCart);

  // Checkout modal triggers
  const checkoutBtn = document.getElementById('openCheckoutBtn');
  const closeCheckoutBtn = document.getElementById('closeCheckoutModalBtn');
  const continueShoppingBtn = document.getElementById('continueShoppingBtn');
  const modalBackdrop = document.getElementById('checkoutModalBackdrop');
  const confirmOrderBtn = document.getElementById('confirmOrderBtn');
  const successDoneBtn = document.getElementById('successDoneBtn');

  if (checkoutBtn) checkoutBtn.addEventListener('click', openCheckoutModal);
  if (closeCheckoutBtn) closeCheckoutBtn.addEventListener('click', closeCheckoutModal);
  if (continueShoppingBtn) continueShoppingBtn.addEventListener('click', closeCheckoutModal);
  if (confirmOrderBtn) confirmOrderBtn.addEventListener('click', handleConfirmDemoOrder);
  if (successDoneBtn) successDoneBtn.addEventListener('click', closeCheckoutModal);

  // Close modal when clicking backdrop outside modal card
  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      if (e.target === modalBackdrop) {
        closeCheckoutModal();
      }
    });
  }

  // Keyboard shortcut: Escape closes drawer and modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeCartDrawer();
      closeCheckoutModal();
    }
  });

  // Category filter pill buttons
  const categoryBar = document.getElementById('categoryFilterBar');
  if (categoryBar) {
    categoryBar.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-pill-btn');
      if (btn) {
        const cat = btn.getAttribute('data-category');
        if (cat) handleCategorySelect(cat);
      }
    });
  }

  // Search input listeners
  const navInput = document.getElementById('navSearchInput');
  const catalogInput = document.getElementById('catalogSearchInput');
  const navClear = document.getElementById('navSearchClear');
  const catalogClear = document.getElementById('catalogSearchClear');

  if (navInput) {
    navInput.addEventListener('input', handleSearchInput);
  }
  if (catalogInput) {
    catalogInput.addEventListener('input', handleSearchInput);
  }

  if (navClear) {
    navClear.addEventListener('click', () => {
      if (navInput) navInput.value = '';
      searchQuery = '';
      navClear.style.display = 'none';
      renderProducts();
    });
  }
  if (catalogClear) {
    catalogClear.addEventListener('click', () => {
      if (catalogInput) catalogInput.value = '';
      searchQuery = '';
      catalogClear.style.display = 'none';
      renderProducts();
    });
  }

  // Sort dropdown
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      activeSort = e.target.value;
      renderProducts();
    });
  }

  // Quick filter buttons in hero
  const heroShopNow = document.getElementById('heroShopNowBtn');
  const heroDealsBtn = document.getElementById('heroDealsBtn');

  if (heroShopNow) {
    heroShopNow.addEventListener('click', () => {
      const catalog = document.getElementById('catalog');
      if (catalog) catalog.scrollIntoView({ behavior: 'smooth' });
    });
  }

  if (heroDealsBtn) {
    heroDealsBtn.addEventListener('click', () => {
      const catalog = document.getElementById('catalog');
      if (catalog) catalog.scrollIntoView({ behavior: 'smooth' });
      // Filter for affordable accessories & deals under ₹500
      activeCategory = 'Accessories';
      document.querySelectorAll('.filter-pill-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-category') === 'Accessories');
      });
      renderProducts();
    });
  }

  // Product Grid Event Delegation (Add to Cart buttons)
  const productGrid = document.getElementById('productGrid');
  if (productGrid) {
    productGrid.addEventListener('click', (e) => {
      const addBtn = e.target.closest('.btn-add-to-cart');
      if (addBtn) {
        const id = addBtn.getAttribute('data-id');
        if (id) addToCart(id);
      }
    });
  }

  // Cart Drawer Event Delegation (Qty -, Qty +, Remove)
  const cartItemsContainer = document.getElementById('cartItemsContainer');
  if (cartItemsContainer) {
    cartItemsContainer.addEventListener('click', (e) => {
      // Decrement button
      const minusBtn = e.target.closest('.btn-qty-minus');
      if (minusBtn) {
        const id = minusBtn.getAttribute('data-id');
        if (id) changeQuantity(id, -1);
        return;
      }

      // Increment button
      const plusBtn = e.target.closest('.btn-qty-plus');
      if (plusBtn) {
        const id = plusBtn.getAttribute('data-id');
        if (id) changeQuantity(id, 1);
        return;
      }

      // Remove button
      const removeBtn = e.target.closest('.btn-remove-item');
      if (removeBtn) {
        const id = removeBtn.getAttribute('data-id');
        if (id) removeItem(id);
        return;
      }
    });
  }

  // Navbar sticky shadow on scroll
  window.addEventListener('scroll', () => {
    const header = document.querySelector('.site-header');
    if (header) {
      if (window.scrollY > 20) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  });
}

// =============================================================================
// 13. APP ENTRYPOINT & EXPORT TO WINDOW (Ensures full accessibility for testing)
// =============================================================================
function initApp() {
  loadCart();
  setupEventListeners();
  renderProducts();
  updateCartBadge();
  renderCart();
  console.log('AuraCraft E-Commerce application initialized successfully.');
}

// Expose core functions to window for evaluation, testing, or inline triggers
window.addToCart = addToCart;
window.changeQuantity = changeQuantity;
window.removeItem = removeItem;
window.renderCart = renderCart;
window.calculateCartTotals = calculateCartTotals;
window.formatCurrency = formatCurrency;
window.openCartDrawer = openCartDrawer;
window.closeCartDrawer = closeCartDrawer;
window.openCheckoutModal = openCheckoutModal;
window.closeCheckoutModal = closeCheckoutModal;
window.clearCart = clearCart;
window.PRODUCTS = PRODUCTS;

// Initialize when DOM content is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
