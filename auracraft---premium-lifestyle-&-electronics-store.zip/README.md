# AuraCraft - Interactive E-Commerce Store with Shopping Cart

An interactive, responsive e-commerce web application featuring dynamic product catalog rendering, search and category filtering, an interactive sliding shopping cart drawer with automated delivery fee calculations, LocalStorage cart persistence, and a checkout preview modal.

Built as an **Internship Capstone Project** using pure, beginner-friendly **HTML5, CSS3, and Vanilla JavaScript (ES6+)**.

---

## 📁 1. FOLDER STRUCTURE

```
auracraft-store/
│
├── index.html          # Semantic HTML5 layout, modal dialogs, and drawer structure
├── style.css           # Pure CSS3 stylesheet (Responsive Grid, Flexbox, Theme, Animations)
├── script.js           # Vanilla ES6+ JavaScript (State, Cart, reduce() math, LocalStorage)
└── README.md           # Project documentation, deployment guides, and test checklist
```

---

## 🚀 2. HOW TO RUN THE PROJECT LOCALLY

### Option A: VS Code "Live Server" (Recommended for Beginners)
1. Install the **Live Server** extension in Visual Studio Code (by Ritwick Dey).
2. Right-click on `index.html` in the file explorer.
3. Select **"Open with Live Server"**.
4. The project will open automatically in your browser at `http://127.0.0.1:5500/index.html`.

### Option B: Python Simple HTTP Server
Open your terminal in the project directory and run:

```bash
# Python 3
python3 -m http.server 8000

# Or Python 2
python -m SimpleHTTPServer 8000
```
Then navigate to `http://localhost:8000` in any web browser.

### Option C: Node.js / `npx serve`
```bash
npx serve .
```

### Option D: Double-Click
You can also directly double-click `index.html` to open it in Chrome, Edge, Firefox, or Safari.

---

## 🐙 3. HOW TO UPLOAD THE PROJECT TO GITHUB

Follow these steps in your terminal to publish the project to your GitHub account:

1. **Initialize Git repository**:
   ```bash
   git init
   ```

2. **Stage all files**:
   ```bash
   git add index.html style.css script.js README.md
   ```

3. **Create the initial commit**:
   ```bash
   git commit -m "feat: complete interactive e-commerce store with cart & localstorage"
   ```

4. **Create a new repository on GitHub**:
   - Go to [github.com/new](https://github.com/new).
   - Enter repository name: `auracraft-ecommerce-store`.
   - Choose **Public**.
   - Do not initialize with README, .gitignore, or license (already created).
   - Click **Create repository**.

5. **Link and push your local repository**:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<YOUR-USERNAME>/auracraft-ecommerce-store.git
   git push -u origin main
   ```

---

## 🌐 4. DEPLOYMENT INSTRUCTIONS

### Method 1: Deploy on GitHub Pages (Free, 2 Minutes)
1. Go to your repository on GitHub (`https://github.com/<YOUR-USERNAME>/auracraft-ecommerce-store`).
2. Click on **Settings** (tab at the top right of the repository).
3. In the left navigation sidebar under "Code and automation", click **Pages**.
4. Under **"Build and deployment" > "Source"**, select **Deploy from a branch**.
5. Under **Branch**, select `main` and folder `/(root)`, then click **Save**.
6. Wait 1-2 minutes. Refresh the page to see your live URL:
   `https://<YOUR-USERNAME>.github.io/auracraft-ecommerce-store/`

### Method 2: Deploy on Netlify (Drag-and-Drop or Git)
#### Via Drag & Drop:
1. Go to [Netlify Drop](https://app.netlify.com/drop).
2. Sign in with GitHub or email.
3. Drag and drop your project folder containing `index.html`, `style.css`, and `script.js`.
4. Netlify will deploy it instantly and provide a live URL (e.g., `https://auracraft-store.netlify.app`).

#### Via Netlify Git Integration:
1. Log in to [Netlify](https://app.netlify.com/).
2. Click **Add new site** > **Import an existing project**.
3. Select **GitHub** and authorize your account.
4. Pick your `auracraft-ecommerce-store` repository.
5. Leave the build command empty and publish directory as `./` (or leave default).
6. Click **Deploy auracraft-store**.

---

## 💡 5. CORE TECHNICAL IMPLEMENTATION DETAILS

### Dynamic Product Rendering
- An array of 12 distinct lifestyle and electronics products (`PRODUCTS`) is defined in `script.js`.
- Each object contains: `id`, `name`, `category`, `price` (stored as pure numbers), `rating`, `reviews`, `image`, and `description`.
- Zero product cards are hardcoded in `index.html`. All cards are rendered dynamically via DOM manipulation (`document.createElement`) in `renderProducts()`.

### Currency Formatting
Indian Rupee currency formatting is applied at presentation time without mutating raw numeric prices:
```javascript
amount.toLocaleString('en-IN', {
  style: 'currency',
  currency: 'INR'
});
```

### Accurate Total Price Calculation with `reduce()`
```javascript
const subtotal = cart.reduce((total, cartItem) => {
  const product = PRODUCTS.find(p => p.id === cartItem.id);
  if (!product) return total;
  return total + (product.price * cartItem.quantity);
}, 0);

let deliveryFee = 0;
if (cart.length > 0) {
  deliveryFee = subtotal >= 500 ? 0 : 40;
}

const grandTotal = subtotal + deliveryFee;
```

### Delivery Fee Tiers
- **Empty Cart**: ₹0 delivery fee.
- **Subtotal < ₹500**: ₹40 delivery fee.
- **Subtotal ≥ ₹500**: Free delivery (₹0).
- An animated progress bar in the cart drawer displays the remaining amount required to unlock free delivery.

### LocalStorage Persistence with Defensive Fallbacks
- Cart state is serialized to JSON and stored in `localStorage` key `'auracraft_cart_v1'` upon every change.
- `loadCart()` validates every item against the product catalog and drops corrupted entries safely without crashing the application.

### Demo Checkout Preview Modal
- Opens order summary modal with detailed product breakdowns, quantities, unit prices, line totals, subtotal, delivery fee, and grand total.
- Prominently displays: `"Demo Checkout – No real payment will be processed."`
- Absolutely no credit/debit card, UPI, or banking information is requested.
- Clicking "Confirm Demo Order" clears the cart, resets LocalStorage, and displays an animated order confirmation screen with a unique reference number.

---

## ✅ 6. REQUIREMENTS VERIFICATION CHECKLIST

| # | Requirement | Status | Notes |
|---|---|---|---|
| 1 | All products render dynamically from JavaScript array | Passed | 12 items rendered dynamically into `#productGrid` |
| 2 | Adding a product works | Passed | `addToCart(id)` works from catalog and hero cards |
| 3 | Adding same product multiple times increases quantity | Passed | Increments quantity without duplicating cart item rows |
| 4 | Increasing quantity works | Passed | `+` button in cart drawer calls `changeQuantity(id, 1)` |
| 5 | Decreasing quantity works | Passed | `−` button in cart drawer calls `changeQuantity(id, -1)` |
| 6 | Decreasing quantity to zero removes item | Passed | Product automatically excised when quantity reaches 0 |
| 7 | Removing a product works | Passed | Trash icon button calls `removeItem(id)` |
| 8 | Removing last item displays empty-cart message | Passed | Shows friendly empty-cart illustration & CTA |
| 9 | Cart count updates correctly | Passed | Live badge in header and drawer count with pop animation |
| 10 | Subtotal is calculated correctly | Passed | Computed via `Array.prototype.reduce` |
| 11 | Delivery fee is calculated correctly | Passed | Automated logic based on subtotal threshold |
| 12 | Grand total is calculated correctly | Passed | `subtotal + deliveryFee` |
| 13 | Free delivery applies at ₹500 and above | Passed | Delivery fee drops to ₹0 when subtotal ≥ ₹500 |
| 14 | ₹40 delivery applies below ₹500 | Passed | Delivery fee set to ₹40 when subtotal < ₹500 |
| 15 | Empty cart has zero delivery fee | Passed | Delivery fee is ₹0 when cart has 0 items |
| 16 | Cart data survives page reload | Passed | Synchronized with `localStorage` on all mutations |
| 17 | Invalid LocalStorage data does not crash application | Passed | `loadCart()` incorporates `try/catch` and schema validation |
| 18 | Checkout modal opens correctly | Passed | Accessible modal opens with smooth backdrop blur |
| 19 | Checkout modal displays accurate order information | Passed | Lists items, quantities, line totals, subtotal, delivery & grand total |
| 20 | Checkout modal closes correctly | Passed | Close button, Continue Shopping, Escape key & backdrop click |
| 21 | Checkout is blocked when cart is empty | Passed | Button is disabled and function returns early with a toast |
| 22 | No payment details are requested | Passed | Zero card/UPI/banking forms; prominent demo disclaimer |
| 23 | Search works | Passed | Instant live filtering across name, category, and description |
| 24 | Category filtering works | Passed | Interactive filter pills: All, Audio, Wearables, Accessories, etc. |
| 25 | Mobile and tablet layouts work correctly | Passed | Fully responsive with CSS Grid, Flexbox, and media queries |
